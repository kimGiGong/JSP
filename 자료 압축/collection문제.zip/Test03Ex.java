package day16;

public class Test03Ex {
	public static void main(String[] args) {
		// 영한 사전 만들기 : HashMap을 이용하여 10개의 단어를 영어,한글의 쌍으로 저장하고 영어로 한글을 검색하는 프로그램을 만들어보세요.
		// 단, exit가 입력되면 프로그램 종료!
		
		
		
		
		
	}
}
package day16;

public class Test04Ex {
	
	public static void main(String[] args) {
		// HashMap을 이용하여 학생 이름과 자바 점수를 기록하는 관리 프로그램을 작성하세요. 
		// 아래 프로그램 메뉴에서 각 번호로 서비스 선택하고, 6번을 입력받으면 프로그램 종료. 
		/*
		 	** 자바 성적 관리 프로그램 **
			1. 전체 조회 
			2. 등록
			3. 수정
			4. 삭제
			5. 전체 평균
			6. 프로그램 종료
		*/
		
		//Test04Ex prg = new Test04Ex();
		//prg.run();
		
		
	}
}
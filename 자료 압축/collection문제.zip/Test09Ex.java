package day16;
/*
	33Ex문제를 ArrayList<StudentClass>대신 HashMap<String, StudentClass> 을 이용하여 다시 작성해보세요. 
	해쉬맵에서 키는 학생 이름으로 한다.
*/
public class Test09Ex {
	
	public static void main(String[] args) {
		//Test09Ex ex = new Test09Ex();
		//ex.run();
	}
}
package web.jsp08.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class BoardDAO {

	// 커넥션 만들어 리턴해주는 메서드 
	private Connection getConnection() throws NamingException, SQLException {
		Context ctx = new InitialContext(); 
		Context env = (Context)ctx.lookup("java:comp/env"); 
		DataSource ds = (DataSource)env.lookup("jdbc/orcl");
		return ds.getConnection(); 
	}
	
	// 글작성 처리 메서드 
	public void insertArticle(BoardDTO article) {
		Connection conn = null; 
		PreparedStatement pstmt = null; 
		try {
			conn = getConnection(); 
			String sql = "insert into board(num,writer,subject,email,content,pw,reg,readcount)";
			sql += " values(board_seq.nextval,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, article.getWriter());
			pstmt.setString(2, article.getSubject());
			pstmt.setString(3, article.getEmail());
			pstmt.setString(4, article.getContent());
			pstmt.setString(5, article.getPw());
			pstmt.setTimestamp(6, article.getReg());
			pstmt.setInt(7, article.getReadcount());
			
			int result = pstmt.executeUpdate(); 
			System.out.println("insert result : " + result);
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) try { pstmt.close(); }catch(SQLException e) { e.printStackTrace(); }
			if(conn != null) try { conn.close(); }catch(SQLException e) { e.printStackTrace(); }
		}
	}
	
	// 게시글 전체 가져오기 
	public List<BoardDTO> getAllArticles() {
		List<BoardDTO> list = null; // 변수만 만듬, 저장공간 아직 안만듬.
		Connection conn = null; 
		PreparedStatement pstmt = null; 
		ResultSet rs = null; 
		try {
			conn = getConnection();
			String sql = "select * from board order by reg desc";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(); 
			
			list = new ArrayList<BoardDTO>(); // 저장공간 만들고 
			while(rs.next()) {
				BoardDTO article = new BoardDTO();  // 레코드 하나 담을 dto 반복할때마다 새로 만들기
				article.setNum(rs.getInt("num"));
				article.setWriter(rs.getString("writer"));
				article.setContent(rs.getString("content"));
				article.setSubject(rs.getString("subject"));
				article.setEmail(rs.getString("email"));
				article.setPw(rs.getString("pw"));
				article.setReg(rs.getTimestamp("reg"));
				article.setReadcount(rs.getInt("readcount"));
				list.add(article);
			}//while
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(rs != null) try {rs.close();}catch(SQLException e) { e.printStackTrace();}
			if(pstmt != null) try {pstmt.close();}catch(SQLException e) { e.printStackTrace();}
			if(conn != null) try {conn.close();}catch(SQLException e) { e.printStackTrace();}
		}

		return list;
	}
	
	// (구버전) 전체 글 개수 리턴해주는 메서드 
	public int getArticleCount() {
		Connection conn = null; 
		PreparedStatement pstmt = null; 
		ResultSet rs = null; 
		int count = 0; // 마지막에 리턴해줄 최종 레코드수 담을 변수 미리 준비 
		try {
			conn = getConnection();  // 커넥션 가져오기 
			String sql = "select count(*) from board"; // 쿼리문작성 : 전체컬럼기준으로 레코드 수 계산해와 
			pstmt = conn.prepareStatement(sql); // 쿼리문 준비시켜 pstmt 리턴받기
			rs = pstmt.executeQuery();  // 실행
			if(rs.next()) { // 결과 있으면, 이때 next를 통해 1번째 레코드 가르키게 
				count = rs.getInt(1); // 1번 컬럼에 있는 값(카운트수) 꺼내서 준비해둔 변수에 담기 
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(rs != null) try { rs.close(); }catch(SQLException e) { e.printStackTrace(); }
			if(pstmt != null) try { pstmt.close(); }catch(SQLException e) { e.printStackTrace(); }
			if(conn != null) try { conn.close(); }catch(SQLException e) { e.printStackTrace(); }
		}
		
		return count;
	}
	
	// 게시글 가져오기 (페이징처리 O) 	
	public List<BoardDTO> getArticleList(int start, int end) {
		List<BoardDTO> list = null; 
		Connection conn = null;
		PreparedStatement pstmt = null; 
		ResultSet rs = null; 
		try {
			
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(rs != null) try { rs.close(); }catch(SQLException e) { e.printStackTrace(); }
			if(pstmt != null) try { pstmt.close(); }catch(SQLException e) { e.printStackTrace(); }
			if(conn != null) try { conn.close(); }catch(SQLException e) { e.printStackTrace(); }
		}
		
		return list; 
	}
	
	
	
	
	
	
	
	
	
}
